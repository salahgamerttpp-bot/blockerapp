package com.example.blocker

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.Intent
import android.os.Bundle

class MyAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        if (event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            val source: AccessibilityNodeInfo? = event.source
            source ?: return

            val text = source.text?.toString() ?: return
            val blocked = BlockerPrefs.getBlockedWords(this)
            for (w in blocked) {
                if (text.contains(w, ignoreCase = true)) {
                    // Try to clear text
                    try {
                        val args = Bundle()
                        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
                        source.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                    } catch (e: Exception) {
                        performGlobalAction(GLOBAL_ACTION_BACK)
                    }
                    // show overlay warning
                    val i = Intent(this, OverlayService::class.java)
                    i.putExtra("msg", "تم حجب كلمة: $w")
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startService(i)
                    break
                }
            }
        }
    }

    override fun onInterrupt() {}
}
