package com.example.blocker

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest

object BlockerPrefs {
    private const val PREFS = "blocker_prefs_v2"
    private const val KEY_WORDS = "blocked_words"
    private const val KEY_DOMAINS = "blocked_domains"
    private const val KEY_APPS = "blocked_apps"
    private const val KEY_PASS = "password_hash"

    // core blocked words (non-editable)
    private val coreBlocked = listOf("sex","porn","إباحية","جنس")

    private fun prefs(ctx: Context): SharedPreferences {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    fun getBlockedWords(ctx: Context): MutableSet<String> {
        val s = prefs(ctx).getStringSet(KEY_WORDS, emptySet())?.toMutableSet() ?: mutableSetOf()
        s.addAll(coreBlocked)
        return s
    }

    fun addBlockedWord(ctx: Context, w: String) {
        val p = prefs(ctx)
        val set = p.getStringSet(KEY_WORDS, mutableSetOf())?.toMutableSet() ?: mutableSetOf()
        set.add(w)
        p.edit().putStringSet(KEY_WORDS, set).apply()
    }

    fun getBlockedDomains(ctx: Context): MutableSet<String> {
        return prefs(ctx).getStringSet(KEY_DOMAINS, mutableSetOf())?.toMutableSet() ?: mutableSetOf()
    }

    fun addBlockedDomain(ctx: Context, d: String) {
        val p = prefs(ctx)
        val set = p.getStringSet(KEY_DOMAINS, mutableSetOf())?.toMutableSet() ?: mutableSetOf()
        set.add(d)
        p.edit().putStringSet(KEY_DOMAINS, set).apply()
    }

    fun getBlockedApps(ctx: Context): MutableSet<String> {
        return prefs(ctx).getStringSet(KEY_APPS, mutableSetOf())?.toMutableSet() ?: mutableSetOf()
    }

    fun addBlockedApp(ctx: Context, packageName: String) {
        val p = prefs(ctx)
        val set = p.getStringSet(KEY_APPS, mutableSetOf())?.toMutableSet() ?: mutableSetOf()
        set.add(packageName)
        p.edit().putStringSet(KEY_APPS, set).apply()
    }

    fun setPassword(ctx: Context, password: String) {
        val hash = sha256(password)
        prefs(ctx).edit().putString(KEY_PASS, hash).apply()
    }

    fun hasPassword(ctx: Context): Boolean {
        val s = prefs(ctx).getString(KEY_PASS, null)
        return !s.isNullOrEmpty()
    }

    fun checkPassword(ctx: Context, pass: String): Boolean {
        val hash = prefs(ctx).getString(KEY_PASS, null) ?: return false
        return sha256(pass) == hash
    }

    private fun sha256(s: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(s.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
