package com.example.blocker

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private val ADMIN_REQUEST = 555

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // if password set, redirect to lock
        if (BlockerPrefs.hasPassword(this)) {
            startActivity(Intent(this, LockActivity::class.java))
        }

        setContentView(R.layout.activity_main)

        val btnManage = findViewById<Button>(R.id.btn_manage)
        val btnToggleVpn = findViewById<Button>(R.id.btn_toggle_vpn)
        val btnEnableAcc = findViewById<Button>(R.id.btn_enable_acc)
        val btnOverlay = findViewById<Button>(R.id.btn_overlay_perm)
        val btnAdmin = findViewById<Button>(R.id.btn_enable_admin)

        btnManage.setOnClickListener {
            startActivity(Intent(this, ManageActivity::class.java))
        }

        btnEnableAcc.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "فعّل خدمة الوصول (Accessibility)", Toast.LENGTH_LONG).show()
        }

        btnOverlay.setOnClickListener {
            // open overlay permission
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "أعطِ الإذن للعرض فوق التطبيقات", Toast.LENGTH_LONG).show()
        }

        btnAdmin.setOnClickListener {
            val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val admin = ComponentName(this, MyDeviceAdminReceiver::class.java)
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "تفعيل حماية التطبيق لمنع إلغاء التثبيت السريع.")
            startActivityForResult(intent, ADMIN_REQUEST)
        }

        btnToggleVpn.setOnClickListener {
            val svc = Intent(this, LocalVpnService::class.java)
            startService(svc)
            Toast.makeText(this, "حاولت تشغيل/تنشيط VPN — تحقق من إشعارات النظام لإقرار الاتصال.", Toast.LENGTH_LONG).show()
        }
    }
}
