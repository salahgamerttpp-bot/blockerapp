package com.example.blocker

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class LockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(android.R.layout.simple_list_item_1) // simple UI: we'll reuse add password dialog from ManageActivity
        // redirect to ManageActivity to set/check password
        startActivity(android.content.Intent(this, ManageActivity::class.java))
        finish()
    }
}
