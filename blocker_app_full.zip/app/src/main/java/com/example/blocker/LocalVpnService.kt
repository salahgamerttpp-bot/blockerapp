package com.example.blocker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import kotlin.concurrent.thread

class LocalVpnService : VpnService() {
    private var vpnInterface: ParcelFileDescriptor? = null
    private var dnsThread: Thread? = null
    private val TAG = "LocalVpnService"

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        setupVpn()
        return START_STICKY
    }

    override fun onDestroy() {
        try {
            dnsThread?.interrupt()
        } catch (e: Exception) {}
        try {
            vpnInterface?.close()
        } catch (e: Exception) {}
        super.onDestroy()
    }

    private fun setupVpn() {
        val builder = Builder()
        builder.setSession("BlockerLocalVpn")
        // local address inside TUN used for DNS intercept attempt
        builder.addAddress("10.0.0.2", 32)
        builder.addRoute("0.0.0.0", 0)
        // tell system to use our local address as DNS: best-effort
        builder.addDnsServer("10.0.0.2")
        builder.setBlocking(false)
        try {
            vpnInterface?.close()
        } catch (e: Exception) {}
        vpnInterface = try {
            builder.establish()
        } catch (e: Exception) {
            null
        }

        createNotificationChannel()
        val n = NotificationCompat.Builder(this, "blocker_vpn")
            .setContentTitle("Blocker — VPN running")
            .setContentText("حجب الدومينات مفعل (تجريبي)")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), 0))
            .build()
        startForeground(123, n)

        // launch DNS proxy thread: listen on TUN address 10.0.0.2:53 (best-effort)
        dnsThread = thread(start = true) {
            try {
                // bind to the VPN-local address on port 53
                val bindAddr = InetAddress.getByName("10.0.0.2")
                val socket = DatagramSocket(53, bindAddr)
                socket.soTimeout = 10000
                val buf = ByteArray(1024)
                Log.i(TAG, "DNS proxy started on 10.0.0.2:53")
                while (!Thread.currentThread().isInterrupted) {
                    val pkt = DatagramPacket(buf, buf.size)
                    socket.receive(pkt)
                    val req = pkt.data.copyOf(pkt.length)
                    val domain = parseDomainFromDnsQuery(req)
                    if (domain != null) {
                        val domains = BlockerPrefs.getBlockedDomains(this)
                        var isBlocked = false
                        for (d in domains) {
                            if (domain.endsWith(d, ignoreCase = true)) {
                                isBlocked = true
                                break
                            }
                        }
                        if (isBlocked) {
                            val resp = buildFakeAResponse(req, byteArrayOf(0,0,0,0))
                            val out = DatagramPacket(resp, resp.size, pkt.address, pkt.port)
                            socket.send(out)
                            continue
                        }
                    }
                    // forward to upstream DNS (Google) and relay response
                    val upstream = DatagramSocket()
                    val upAddr = InetAddress.getByName("8.8.8.8")
                    val outp = DatagramPacket(req, req.size, upAddr, 53)
                    upstream.send(outp)
                    val rbuf = ByteArray(1024)
                    val rcv = DatagramPacket(rbuf, rbuf.size)
                    upstream.soTimeout = 3000
                    try {
                        upstream.receive(rcv)
                        val resp = rcv.data.copyOf(rcv.length)
                        val out = DatagramPacket(resp, resp.size, pkt.address, pkt.port)
                        socket.send(out)
                    } catch (e: Exception) {
                        // ignore
                    } finally {
                        upstream.close()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "DNS proxy thread error: " + e.message)
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel("blocker_vpn", "Blocker VPN", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(channel)
        }
    }

    // minimal DNS parser to extract QNAME
    private fun parseDomainFromDnsQuery(data: ByteArray): String? {
        try {
            var idx = 12
            val labels = mutableListOf<String>()
            while (idx < data.size) {
                val len = data[idx].toInt() and 0xFF
                if (len == 0) { idx++; break }
                if (len + idx >= data.size) return null
                val label = String(data, idx+1, len)
                labels.add(label)
                idx += len + 1
            }
            if (labels.isEmpty()) return null
            return labels.joinToString(".")
        } catch (e: Exception) {
            return null
        }
    }

    // build a simple DNS response with an A record (IPv4 4 bytes)
    private fun buildFakeAResponse(request: ByteArray, ipv4: ByteArray): ByteArray {
        try {
            val id0 = request[0]
            val id1 = request[1]
            // flags: set QR bit and RA
            val flags = ((request[2].toInt() and 0xFF) shl 8) or (request[3].toInt() and 0xFF)
            val respFlags = (flags or 0x8000 or 0x0080).toShort()
            val qdcount = 1
            val ancount = 1
            val ns = 0
            val ar = 0
            val header = ByteArray(12)
            header[0] = id0; header[1] = id1
            header[2] = ((respFlags.toInt() shr 8) and 0xFF).toByte()
            header[3] = (respFlags.toInt() and 0xFF).toByte()
            header[4] = 0; header[5] = 1
            header[6] = 0; header[7] = 1
            header[8] = 0; header[9] = 0
            header[10] = 0; header[11] = 0

            // copy question from request (starting at 12) until end of question (including QTYPE and QCLASS)
            var idx = 12
            while (idx < request.size) {
                if (request[idx].toInt() == 0) { // end of name
                    idx += 5 // zero byte + qtype(2) + qclass(2)
                    break
                } else {
                    idx++
                }
            }
            if (idx > request.size) idx = request.size
            val question = request.copyOfRange(12, idx)

            // answer: name pointer (C00C), type A, class IN, ttl 60, rdlength 4, rdata ipv4
            val answer = ByteArray(12 + 4)
            // pointer to offset 12
            answer[0] = 0xC0.toByte()
            answer[1] = 0x0C.toByte()
            // TYPE A
            answer[2] = 0; answer[3] = 1
            // CLASS IN
            answer[4] = 0; answer[5] = 1
            // TTL 60
            answer[6] = 0; answer[7] = 0; answer[8] = 0; answer[9] = 60
            // RDLENGTH 4
            answer[10] = 0; answer[11] = 4
            // rdata
            System.arraycopy(ipv4, 0, answer, 12, 4)

            // assemble response
            val resp = ByteArray(header.size + question.size + answer.size)
            System.arraycopy(header, 0, resp, 0, header.size)
            System.arraycopy(question, 0, resp, header.size, question.size)
            System.arraycopy(answer, 0, resp, header.size + question.size, answer.size)
            return resp
        } catch (e: Exception) {
            return ByteArray(0)
        }
    }
}
