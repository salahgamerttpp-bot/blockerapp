package com.example.blocker

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import android.widget.Toast

class ManageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage)

        val etWord = findViewById<EditText>(R.id.et_word)
        val btnAddWord = findViewById<Button>(R.id.btn_add_word)
        val etDomain = findViewById<EditText>(R.id.et_domain)
        val btnAddDomain = findViewById<Button>(R.id.btn_add_domain)
        val etApp = findViewById<EditText>(R.id.et_app)
        val btnAddApp = findViewById<Button>(R.id.btn_add_app)
        val btnChangePass = findViewById<Button>(R.id.btn_change_pass)

        btnAddWord.setOnClickListener {
            val w = etWord.text.toString().trim()
            if (w.isNotEmpty()) {
                BlockerPrefs.addBlockedWord(this, w)
                Toast.makeText(this, "أضيفت: $w", Toast.LENGTH_SHORT).show()
                etWord.setText("")
            }
        }

        btnAddDomain.setOnClickListener {
            val d = etDomain.text.toString().trim().lowercase()
            if (d.isNotEmpty()) {
                BlockerPrefs.addBlockedDomain(this, d)
                Toast.makeText(this, "أضيف دومين: $d", Toast.LENGTH_SHORT).show()
                etDomain.setText("")
            }
        }

        btnAddApp.setOnClickListener {
            val a = etApp.text.toString().trim()
            if (a.isNotEmpty()) {
                BlockerPrefs.addBlockedApp(this, a)
                Toast.makeText(this, "أضيف تطبيق: $a", Toast.LENGTH_SHORT).show()
                etApp.setText("")
            }
        }

        btnChangePass.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("تعيين/تغيير كلمة المرور")
            val input = EditText(this)
            builder.setView(input)
            builder.setPositiveButton("حفظ") { _, _ ->
                val pass = input.text.toString()
                if (pass.length >= 4) {
                    BlockerPrefs.setPassword(this, pass)
                    Toast.makeText(this, "تم حفظ كلمة المرور", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "اختر كلمة مرور 4 أحرف على الأقل", Toast.LENGTH_SHORT).show()
                }
            }
            builder.setNegativeButton("إلغاء", null)
            builder.show()
        }
    }
}
