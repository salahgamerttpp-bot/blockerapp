package com.example.blocker

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var view: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val msg = intent?.getStringExtra("msg") ?: "محتوى محظور"
        showOverlay(msg)
        // auto-stop after 3 seconds
        Handler(mainLooper).postDelayed({ stopSelf() }, 3000)
        return START_NOT_STICKY
    }

    private fun showOverlay(msg: String) {
        if (view != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this)
        tv.text = msg
        tv.textSize = 18f
        tv.setBackgroundColor(0xAA000000.toInt())
        tv.setTextColor(0xFFFFFFFF.toInt())
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.TOP
        windowManager?.addView(tv, params)
        view = tv
    }

    override fun onDestroy() {
        try {
            if (view != null) {
                windowManager?.removeView(view)
                view = null
            }
        } catch (e: Exception) {}
        super.onDestroy()
    }
}
