rootProject.name = "BlockerAppFull"
include(":app")
