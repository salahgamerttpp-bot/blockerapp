BUILD ON PHONE (Termux -> proot Ubuntu) - Summary steps (detailed steps follow)

**ملحوظة مهمة:** هذه الطريقة تتطلب مساحة كبيرة (1-4+ جيجابايت) ووقت لتنزيل Android SDK و build tools.

1) تثبيت Termux (من F-Droid أو Play Store) ثم فتحه.
2) في Termux:
   pkg update
   pkg install proot-distro wget unzip git -y
   proot-distro install ubuntu-20.04
   proot-distro login ubuntu-20.04
3) داخل Ubuntu:
   apt update && apt install openjdk-17-jdk wget unzip git -y
   mkdir -p ~/android-sdk; cd ~/android-sdk
   wget https://dl.google.com/android/repository/commandlinetools-linux-9477386_latest.zip
   unzip commandlinetools-*-latest.zip -d cmdline-tools
   export ANDROID_SDK_ROOT=$HOME/android-sdk
   export PATH=$PATH:$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$ANDROID_SDK_ROOT/platform-tools
   yes | cmdline-tools/bin/sdkmanager --licenses
   cmdline-tools/bin/sdkmanager "platform-tools" "platforms;android-33" "build-tools;33.0.0"
   # install gradle
   apt install gradle -y
4) استخرج المشروع داخل Ubuntu (انسخ ملف ZIP إلى الجهاز وافتحه، أو استخدم git clone)
5) داخل مجلد المشروع:
   gradle assembleDebug
   # أو ./gradlew assembleDebug إن أضفت gradle wrapper
6) الناتج APK سيجد في app/build/outputs/apk/debug/app-debug.apk
7) انسخ الملف إلى مجلد مشترك في Termux ثم ثبت عبر:
   adb install -r app-debug.apk
   # أو نقل الملف إلى الهاتف وتثبيته يدوياً (سماح تثبيت من مصادر غير معروفة)

-------------------------------------------------------
ALTERNATIVE: GitHub Actions
- ارفع المشروع إلى GitHub (من هاتفك عبر متصفح أو تطبيق GitHub).
- أنشئ ملف workflow بسيط لتشغيل `./gradlew assembleDebug`.
- بعد التشغيل حمل الـartifact من صفحة Actions.
- هذه الطريقه أبسط إن لم ترغب في إعداد Termux أو تثبيت حزم كبيرة.
